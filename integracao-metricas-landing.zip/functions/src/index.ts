import * as functions from "firebase-functions/v1";
import * as admin from "firebase-admin";
import { createHash } from "node:crypto";
import { defineSecret } from "firebase-functions/params";
import { onDocumentWritten } from "firebase-functions/v2/firestore";
import { onRequest } from "firebase-functions/v2/https";
import {
  calcularVendaNoServidor,
  type RegraTaxaVenda,
} from "./motorVendas";

if (!admin.apps.length) {
  admin.initializeApp();
}

const db = admin.firestore();
const mercadoPagoAccessToken = defineSecret(
  "MERCADO_PAGO_ACCESS_TOKEN",
);

const PROJETO_ID = "sistema-navegacao";
const REGIAO = "us-central1";
const URL_WEBHOOK_MERCADO_PAGO =
  `https://${REGIAO}-${PROJETO_ID}.cloudfunctions.net/webhookMercadoPagoCmb`;

type PassageiroRecebido = {
  nome?: string;
  documento?: string;
  nacionalidade?: string;
  nascimento?: string;
};

type DadosPagamentoMercadoPago = {
  id?: number | string;
  status?: string;
  transaction_amount?: number;
  external_reference?: string;
  fee_details?: Array<{
    amount?: number;
    type?: string;
  }>;
  point_of_interaction?: {
    transaction_data?: {
      qr_code?: string;
      qr_code_base64?: string;
      ticket_url?: string;
    };
  };
};

function texto(valor: unknown) {
  return String(valor ?? "").trim();
}

function numero(valor: unknown, padrao = 0) {
  const resultado = Number(valor);
  return Number.isFinite(resultado) ? resultado : padrao;
}

function moeda(valor: number) {
  return Math.round((valor + Number.EPSILON) * 100) / 100;
}

function cpfLimpo(valor: unknown) {
  return texto(valor).replace(/\D/g, "");
}

function cpfMascarado(valor: unknown) {
  const cpf = cpfLimpo(valor);

  if (cpf.length !== 11) {
    return "***.***.***-**";
  }

  return `***.***.***-${cpf.slice(-2)}`;
}

function normalizar(valor: unknown) {
  return texto(valor)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/\s+/g, " ");
}

function primeiroNumero(
  objeto: Record<string, unknown>,
  campos: string[],
) {
  for (const campo of campos) {
    const valor = numero(objeto[campo], Number.NaN);

    if (Number.isFinite(valor)) {
      return valor;
    }
  }

  return 0;
}

function obterIdBarcoDaGrade(grade: Record<string, unknown>) {
  const candidatos = [
    grade.barcoId,
    grade.embarcacaoId,
    grade.idBarco,
    grade.id_barco,
    grade.barco_id,
    grade.embarcacao_id,
  ];

  return texto(
    candidatos.find((valor) => texto(valor)),
  );
}

function obterNomeBarcoDaGrade(
  grade: Record<string, unknown>,
) {
  const candidatos = [
    grade.nome_barco,
    grade.nomeBarco,
    grade.barcoNome,
    grade.embarcacaoNome,
    grade.nomeEmbarcacao,
  ];

  return texto(
    candidatos.find((valor) => texto(valor)),
  );
}

function obterConfiguracaoVendas(
  barco: Record<string, unknown>,
) {
  const vendas =
    (barco.vendasPassagens as Record<string, unknown>) || {};
  const regra =
    (vendas.regraTaxa as RegraTaxaVenda) || {};
  const pagamento =
    (vendas.pagamento as Record<string, unknown>) || {};
  const financeiro =
    (barco.financeiroMercadoPago as Record<string, unknown>) ||
    {};

  return {
    ativa:
      vendas.ativa === true ||
      barco.vendaPassagemHabilitada === true ||
      financeiro.vendaPassagemHabilitada === true,
    regraTaxa: {
      ...regra,
      percentual:
        regra.percentual ??
        numero(financeiro.taxaPlataformaPercentual),
      valorFixo:
        regra.valorFixo ??
        numero(financeiro.taxaPlataformaValorFixo),
    } as RegraTaxaVenda,
    pagamento: {
      pixAtivo: pagamento.pixAtivo !== false,
      mercadoPagoConectado:
        pagamento.mercadoPagoConectado === true ||
        financeiro.contaConectada === true,
      vendedorMercadoPagoId: texto(
        pagamento.vendedorMercadoPagoId ||
          financeiro.vendedorMercadoPagoId,
      ),
    },
    limiteHorasAntesSaida: Math.max(
      0,
      numero(vendas.limiteHorasAntesSaida, 2),
    ),
  };
}

async function autenticarRequisicao(
  req: {
    headers: {
      authorization?: string | string[];
    };
  },
) {
  const cabecalho = texto(req.headers.authorization);

  if (!cabecalho.startsWith("Bearer ")) {
    throw new Error("UNAUTHENTICATED");
  }

  const token = cabecalho.slice(7).trim();

  if (!token) {
    throw new Error("UNAUTHENTICATED");
  }

  return admin.auth().verifyIdToken(token);
}

async function localizarBarcoDaGrade(
  grade: Record<string, unknown>,
  barcoIdInformado: string,
) {
  const idDaGrade = obterIdBarcoDaGrade(grade);

  if (idDaGrade) {
    const snap = await db
      .collection("embarcacoes")
      .doc(idDaGrade)
      .get();

    if (snap.exists) {
      return {
        id: snap.id,
        dados: snap.data() as Record<string, unknown>,
      };
    }
  }

  const nomeGrade = normalizar(
    obterNomeBarcoDaGrade(grade),
  );

  if (barcoIdInformado) {
    const snap = await db
      .collection("embarcacoes")
      .doc(barcoIdInformado)
      .get();

    if (snap.exists) {
      const dados = snap.data() as Record<string, unknown>;
      const nomes = [
        dados.nome,
        dados.nome_barco,
        dados.nomeBarco,
        dados.apelido,
      ].map(normalizar);

      if (!nomeGrade || nomes.includes(nomeGrade)) {
        return {
          id: snap.id,
          dados,
        };
      }
    }
  }

  const barcosSnap = await db
    .collection("embarcacoes")
    .get();

  for (const documento of barcosSnap.docs) {
    const dados = documento.data() as Record<
      string,
      unknown
    >;
    const nomes = [
      dados.nome,
      dados.nome_barco,
      dados.nomeBarco,
      dados.apelido,
    ].map(normalizar);

    if (nomeGrade && nomes.includes(nomeGrade)) {
      return {
        id: documento.id,
        dados,
      };
    }
  }

  return null;
}

function localizarParadaDestino(
  grade: Record<string, unknown>,
  destino: string,
) {
  const itinerario = Array.isArray(grade.itinerario)
    ? grade.itinerario
    : Array.isArray(grade.escalas)
      ? grade.escalas
      : [];

  const destinoNormalizado = normalizar(destino).split(" - ")[0];

  return (
    itinerario.find((item) => {
      const parada = item as Record<string, unknown>;
      const nome = normalizar(
        parada.porto || parada.cidade,
      ).split(" - ")[0];

      return nome === destinoNormalizado;
    }) as Record<string, unknown> | undefined
  );
}

function calcularPrecoOficial(
  parada: Record<string, unknown>,
  tipoVaga: string,
) {
  if (tipoVaga === "poltrona") {
    return primeiroNumero(parada, [
      "preco_poltrona",
      "precoPoltrona",
    ]);
  }

  if (tipoVaga === "suite") {
    return primeiroNumero(parada, [
      "preco_suite",
      "precoSuite",
    ]);
  }

  return primeiroNumero(parada, [
    "preco_da_origem",
    "precoRede",
    "preco_rede",
    "preco",
  ]);
}

function obterCapacidade(
  grade: Record<string, unknown>,
  tipoVaga: string,
) {
  const camposPorTipo: Record<string, string[]> = {
    rede: [
      "capacidadeRede",
      "capacidade_rede",
      "vagasRede",
      "vagas_rede",
      "totalRedes",
    ],
    poltrona: [
      "capacidadePoltrona",
      "capacidade_poltrona",
      "vagasPoltrona",
      "vagas_poltrona",
      "totalPoltronas",
    ],
    suite: [
      "capacidadeSuite",
      "capacidade_suite",
      "vagasSuite",
      "vagas_suite",
      "totalSuites",
    ],
  };

  const especifica = primeiroNumero(
    grade,
    camposPorTipo[tipoVaga] || [],
  );

  if (especifica > 0) {
    return Math.floor(especifica);
  }

  const geral = primeiroNumero(grade, [
    "capacidade",
    "capacidadeTotal",
    "capacidade_total",
    "lotacao",
  ]);

  return geral > 0 ? Math.floor(geral) : null;
}

async function contarPassagensOcupadas(
  idViagem: string,
  tipoVaga: string,
) {
  const snapshot = await db
    .collection("passagens")
    .where("idViagem", "==", idViagem)
    .get();

  return snapshot.docs.filter((documento) => {
    const dados = documento.data();
    const status = texto(dados.status).toUpperCase();
    const tipo = texto(dados.tipoVaga).toLowerCase();

    const cancelada = [
      "CANCELADO",
      "CANCELADA",
      "REJEITADO",
      "REEMBOLSADO",
    ].includes(status);

    return !cancelada && (!tipo || tipo === tipoVaga);
  }).length;
}

function statusPassagem(statusPagamento: string) {
  const status = normalizar(statusPagamento);

  if (status === "approved") return "APROVADO";
  if (status === "refunded") return "REEMBOLSADO";
  if (status === "cancelled") return "CANCELADO";
  if (status === "rejected") return "REJEITADO";
  if (status === "charged_back") return "CONTESTADO";

  return "PENDENTE";
}

function statusVenda(statusPagamento: string) {
  const status = normalizar(statusPagamento);

  if (status === "approved") return "confirmada";
  if (status === "refunded") return "reembolsada";
  if (status === "cancelled") return "cancelada";
  if (status === "rejected") return "rejeitada";
  if (status === "charged_back") return "contestada";

  return "aguardando_pagamento";
}

function taxaProcessador(
  pagamento: DadosPagamentoMercadoPago,
) {
  return moeda(
    (pagamento.fee_details || []).reduce(
      (total, item) => total + numero(item.amount),
      0,
    ),
  );
}

async function consultarPagamentoMercadoPago(
  pagamentoId: string,
  accessToken: string,
) {
  const resposta = await fetch(
    `https://api.mercadopago.com/v1/payments/${encodeURIComponent(
      pagamentoId,
    )}`,
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        Accept: "application/json",
      },
    },
  );

  const dados =
    (await resposta.json()) as DadosPagamentoMercadoPago;

  if (!resposta.ok) {
    throw new Error(
      `Mercado Pago respondeu ${resposta.status}.`,
    );
  }

  return dados;
}

export const receberDadosGPS = functions.https.onRequest(
  async (req, res) => {
    try {
      const dados = req.body;

      if (!dados.idBarco || !dados.lat || !dados.lng) {
        res.status(400).send("Dados incompletos.");
        return;
      }

      const timestamp =
        admin.firestore.FieldValue.serverTimestamp();
      const pontoGeografico =
        new admin.firestore.GeoPoint(
          dados.lat,
          dados.lng,
        );

      await db
        .collection("embarcacoes")
        .doc(dados.idBarco)
        .set(
          {
            ultima_posicao: pontoGeografico,
            velocidade: dados.vel || 0,
            rumo: dados.rumo || 0,
            ultima_atualizacao: timestamp,
          },
          { merge: true },
        );

      await db
        .collection("embarcacoes")
        .doc(dados.idBarco)
        .collection("rastros_viagem")
        .add({
          posicao: pontoGeografico,
          timestamp,
          velocidade: dados.vel || 0,
        });

      res
        .status(200)
        .send("Posição e rastro gravados!");
    } catch (error) {
      console.error(error);
      res
        .status(500)
        .send("Erro ao processar sinal.");
    }
  },
);

export const gerarPixSeguro = onRequest(
  {
    region: REGIAO,
    cors: true,
    secrets: [mercadoPagoAccessToken],
    timeoutSeconds: 60,
  },
  async (req, res) => {
    if (req.method !== "POST") {
      res
        .status(405)
        .json({ erro: "Método não permitido." });
      return;
    }

    try {
      const usuario =
        await autenticarRequisicao(req);
      const corpo =
        (req.body || {}) as Record<string, unknown>;

      const gradeId = texto(corpo.gradeId);
      const idViagem = texto(corpo.idViagem);
      const barcoIdInformado = texto(corpo.barcoId);
      const origem = texto(corpo.origem);
      const destino = texto(corpo.destino);
      const tipoVaga = texto(corpo.tipoVaga).toLowerCase();
      const dataViagem = texto(corpo.dataViagem);
      const horarioSaida = texto(corpo.horarioSaida);
      const incluiRefeicao = corpo.refeicao === true;
      const chaveCliente = texto(
        corpo.chaveIdempotencia,
      ).slice(0, 150);
      const passageiros = Array.isArray(corpo.passageiros)
        ? (corpo.passageiros as PassageiroRecebido[])
        : [];

      if (
        !gradeId ||
        !idViagem ||
        !origem ||
        !destino ||
        !["rede", "poltrona", "suite"].includes(
          tipoVaga,
        )
      ) {
        res.status(400).json({
          erro: "Dados da viagem incompletos.",
        });
        return;
      }

      if (
        passageiros.length < 1 ||
        passageiros.length > 20
      ) {
        res.status(400).json({
          erro:
            "A compra deve ter entre 1 e 20 passageiros.",
        });
        return;
      }

      const passageiroInvalido = passageiros.find(
        (passageiro) =>
          texto(passageiro.nome).split(/\s+/).length < 2 ||
          cpfLimpo(passageiro.documento).length !== 11,
      );

      if (passageiroInvalido) {
        res.status(400).json({
          erro: "Confira o nome completo e o CPF dos passageiros.",
        });
        return;
      }

      const gradeSnap = await db
        .collection("grades_viagens")
        .doc(gradeId)
        .get();

      if (!gradeSnap.exists) {
        res.status(404).json({
          erro: "Viagem não encontrada.",
        });
        return;
      }

      const grade =
        gradeSnap.data() as Record<string, unknown>;
      const barcoLocalizado =
        await localizarBarcoDaGrade(
          grade,
          barcoIdInformado,
        );

      if (!barcoLocalizado) {
        res.status(404).json({
          erro:
            "Não foi possível vincular a viagem à embarcação.",
        });
        return;
      }

      const configuracao = obterConfiguracaoVendas(
        barcoLocalizado.dados,
      );

      if (
        !configuracao.ativa ||
        !configuracao.pagamento.pixAtivo
      ) {
        res.status(403).json({
          erro:
            "A venda de passagens não está habilitada para esta embarcação.",
        });
        return;
      }

      const parada = localizarParadaDestino(
        grade,
        destino,
      );

      if (!parada) {
        res.status(400).json({
          erro:
            "O destino não foi localizado no itinerário.",
        });
        return;
      }

      const valorUnitarioPassagem =
        calcularPrecoOficial(parada, tipoVaga);
      const valorUnitarioRefeicao =
        incluiRefeicao
          ? primeiroNumero(parada, [
              "preco_refeicao",
              "precoRefeicao",
            ])
          : 0;

      if (valorUnitarioPassagem <= 0) {
        res.status(400).json({
          erro:
            "O preço oficial desta acomodação não está configurado.",
        });
        return;
      }

      const capacidade = obterCapacidade(
        grade,
        tipoVaga,
      );

      if (capacidade !== null) {
        const ocupadas =
          await contarPassagensOcupadas(
            idViagem,
            tipoVaga,
          );

        if (
          ocupadas + passageiros.length >
          capacidade
        ) {
          res.status(409).json({
            erro:
              "Não há vagas suficientes para esta compra.",
            capacidade,
            ocupadas,
            solicitadas: passageiros.length,
          });
          return;
        }
      }

      const calculo = calcularVendaNoServidor({
        regra: configuracao.regraTaxa,
        quantidade: passageiros.length,
        valorUnitarioPassagem,
        valorAdicionais:
          valorUnitarioRefeicao *
          passageiros.length,
      });

      const chaveBase = [
        usuario.uid,
        chaveCliente ||
          `${idViagem}-${Date.now()}`,
      ].join("|");
      const hash = createHash("sha256")
        .update(chaveBase)
        .digest("hex");
      const vendaId = `VND-${hash.slice(0, 24)}`;
      const vendaRef = db
        .collection("vendas")
        .doc(vendaId);
      const existente = await vendaRef.get();

      if (existente.exists) {
        const dadosExistentes = existente.data() || {};
        const pagamentoExistente =
          (dadosExistentes.pagamento ||
            {}) as Record<string, unknown>;

        if (
          dadosExistentes.compradorUid !==
          usuario.uid
        ) {
          res.status(403).json({
            erro: "Venda não pertence ao usuário.",
          });
          return;
        }

        if (
          texto(pagamentoExistente.id) &&
          texto(pagamentoExistente.qrCode)
        ) {
          res.status(200).json({
            vendaId,
            id_transacao: texto(
              pagamentoExistente.id,
            ),
            qr_code_copia_cola: texto(
              pagamentoExistente.qrCode,
            ),
            qr_code_base64: texto(
              pagamentoExistente.qrCodeBase64,
            ),
            status: texto(
              pagamentoExistente.status,
            ),
            financeiro:
              dadosExistentes.financeiro ||
              calculo,
          });
          return;
        }
      }

      const nomeBarco = texto(
        barcoLocalizado.dados.nome ||
          barcoLocalizado.dados.nome_barco ||
          obterNomeBarcoDaGrade(grade) ||
          barcoLocalizado.id,
      );
      const emailComprador = texto(
        usuario.email || corpo.email,
      );

      await vendaRef.set(
        {
          vendaId,
          chaveIdempotenciaCliente:
            chaveCliente || null,
          compradorUid: usuario.uid,
          compradorEmail: emailComprador,
          compradorCidadeResidencia:
            texto(
              corpo.compradorCidadeResidenciaCompleta ||
                corpo.compradorCidadeResidencia,
            ),
          barcoId: barcoLocalizado.id,
          barcoNome: nomeBarco,
          ownerId: texto(
            barcoLocalizado.dados.ownerId,
          ),
          ownerEmail: texto(
            barcoLocalizado.dados.ownerEmail ||
              barcoLocalizado.dados.emailDono,
          ),
          gradeId,
          viagemId: idViagem,
          origem,
          destino,
          dataViagem,
          horarioSaida,
          tipoVaga,
          incluiRefeicao,
          quantidadePassagens:
            passageiros.length,
          quantidadePassageiros:
            passageiros.length,
          valorUnitarioPassagem,
          valorUnitarioRefeicao,
          valorPassagens:
            calculo.valorPassagens,
          valorAdicionais:
            calculo.valorAdicionais,
          valorTotalCobrado:
            calculo.totalPagoPassageiro,
          totalPagoPassageiro:
            calculo.totalPagoPassageiro,
          valorBrutoArmador:
            calculo.valorBrutoArmador,
          valorLiquidoArmador:
            calculo.valorLiquidoArmador,
          taxaPlataformaValor:
            calculo.receitaBrutaPlataforma,
          receitaBrutaPlataforma:
            calculo.receitaBrutaPlataforma,
          taxaProcessadorValor: 0,
          receitaLiquidaPlataforma:
            calculo.receitaLiquidaPlataforma,
          taxaAplicada: calculo.taxaAplicada,
          financeiro: calculo,
          formaPagamento: "pix",
          statusPagamento:
            "criando_pagamento",
          statusVenda:
            "criando_pagamento",
          bilhetesEmitidos: 0,
          criadoEm:
            admin.firestore.FieldValue.serverTimestamp(),
          atualizadoEm:
            admin.firestore.FieldValue.serverTimestamp(),
        },
        { merge: true },
      );

      const accessToken =
        mercadoPagoAccessToken.value();

      if (!accessToken) {
        throw new Error(
          "O segredo MERCADO_PAGO_ACCESS_TOKEN não está configurado.",
        );
      }

      const pagamentoResposta = await fetch(
        "https://api.mercadopago.com/v1/payments",
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
            Accept: "application/json",
            "X-Idempotency-Key": vendaId,
          },
          body: JSON.stringify({
            transaction_amount:
              calculo.totalPagoPassageiro,
            description:
              `Passagem ${nomeBarco}: ${origem} para ${destino}`,
            payment_method_id: "pix",
            external_reference: vendaId,
            notification_url:
              URL_WEBHOOK_MERCADO_PAGO,
            payer: {
              email: emailComprador,
              first_name:
                texto(passageiros[0].nome)
                  .split(/\s+/)[0] || "Passageiro",
              identification: {
                type: "CPF",
                number: cpfLimpo(
                  passageiros[0].documento,
                ),
              },
            },
            metadata: {
              venda_id: vendaId,
              barco_id: barcoLocalizado.id,
              viagem_id: idViagem,
            },
          }),
        },
      );

      const pagamento =
        (await pagamentoResposta.json()) as DadosPagamentoMercadoPago;

      if (!pagamentoResposta.ok) {
        await vendaRef.set(
          {
            statusPagamento:
              "erro_ao_criar_pagamento",
            statusVenda:
              "erro_ao_criar_pagamento",
            erroPagamento: pagamento,
            atualizadoEm:
              admin.firestore.FieldValue.serverTimestamp(),
          },
          { merge: true },
        );

        res.status(502).json({
          erro:
            "O Mercado Pago não conseguiu criar o Pix.",
          detalhes: pagamento,
        });
        return;
      }

      const pagamentoId = texto(pagamento.id);
      const dadosQr =
        pagamento.point_of_interaction
          ?.transaction_data;
      const qrCode = texto(dadosQr?.qr_code);
      const qrCodeBase64 = texto(
        dadosQr?.qr_code_base64,
      );
      const taxaMp =
        taxaProcessador(pagamento);
      const receitaLiquida = moeda(
        calculo.receitaBrutaPlataforma -
          taxaMp,
      );

      if (!pagamentoId || !qrCode) {
        await vendaRef.set(
          {
            statusPagamento:
              "resposta_pix_incompleta",
            statusVenda:
              "resposta_pix_incompleta",
            pagamentoResposta: pagamento,
            atualizadoEm:
              admin.firestore.FieldValue.serverTimestamp(),
          },
          { merge: true },
        );

        res.status(502).json({
          erro:
            "O Mercado Pago retornou um Pix incompleto.",
        });
        return;
      }

      const batch = db.batch();

      batch.set(
        vendaRef,
        {
          pagamentoId,
          statusPagamento:
            texto(pagamento.status) || "pending",
          statusVenda: statusVenda(
            texto(pagamento.status),
          ),
          taxaProcessadorValor: taxaMp,
          receitaLiquidaPlataforma:
            receitaLiquida,
          pagamento: {
            id: pagamentoId,
            status:
              texto(pagamento.status) ||
              "pending",
            qrCode,
            qrCodeBase64,
            ticketUrl: texto(
              dadosQr?.ticket_url,
            ),
          },
          atualizadoEm:
            admin.firestore.FieldValue.serverTimestamp(),
        },
        { merge: true },
      );

      passageiros.forEach(
        (passageiro, indice) => {
          const ticketId =
            `TKT-${pagamentoId}-${indice}`;
          const ticketRef = db
            .collection("passagens")
            .doc(ticketId);
          const rateio =
            passageiros.length || 1;

          batch.set(
            ticketRef,
            {
              ticketId,
              vendaId,
              pagamentoId,
              barco: nomeBarco,
              barcoId:
                barcoLocalizado.id,
              ownerId: texto(
                barcoLocalizado.dados.ownerId,
              ),
              ownerEmail: texto(
                barcoLocalizado.dados.ownerEmail ||
                  barcoLocalizado.dados.emailDono,
              ),
              compradorUid: usuario.uid,
              compradorEmail:
                emailComprador,
              compradorCidadeResidencia:
                texto(
                  corpo.compradorCidadeResidencia,
                ),
              compradorEstadoResidencia:
                texto(
                  corpo.compradorEstadoResidencia,
                ),
              compradorEstadoResidenciaNome:
                texto(
                  corpo.compradorEstadoResidenciaNome,
                ),
              compradorCidadeResidenciaCompleta:
                texto(
                  corpo.compradorCidadeResidenciaCompleta,
                ),
              compradorCidadeResidenciaCodigoIbge:
                texto(
                  corpo.compradorCidadeResidenciaCodigoIbge,
                ),
              compradorCidadeResidenciaFonte:
                texto(
                  corpo.compradorCidadeResidenciaFonte ||
                    "ibge",
                ),
              dataCompra:
                admin.firestore.FieldValue.serverTimestamp(),
              dataViagem,
              horarioSaida,
              gradeId,
              idViagem,
              origem,
              destino,
              passageiro:
                texto(passageiro.nome),
              documento:
                cpfMascarado(
                  passageiro.documento,
                ),
              documentoMascarado:
                cpfMascarado(
                  passageiro.documento,
                ),
              documentoFinal:
                cpfLimpo(
                  passageiro.documento,
                ).slice(-4),
              nacionalidade:
                texto(
                  passageiro.nacionalidade ||
                    "Brasileira",
                ),
              nascimento: "",
              nascimentoInformado:
                Boolean(
                  texto(passageiro.nascimento),
                ),
              dadosSensiveisProtegidos: true,
              status: statusPassagem(
                texto(pagamento.status),
              ),
              tipoVaga,
              refeicao:
                incluiRefeicao,
              valorPassagem:
                moeda(
                  calculo.valorPassagens /
                    rateio,
                ),
              valorRefeicao:
                moeda(
                  calculo.valorAdicionais /
                    rateio,
                ),
              taxaPlataformaRateada:
                moeda(
                  calculo.receitaBrutaPlataforma /
                    rateio,
                ),
              taxaPagaPassageiroRateada:
                moeda(
                  calculo.taxaPagaPassageiro /
                    rateio,
                ),
              taxaDescontadaArmadorRateada:
                moeda(
                  calculo.taxaDescontadaArmador /
                    rateio,
                ),
              valorTotalRateado:
                moeda(
                  calculo.totalPagoPassageiro /
                    rateio,
                ),
              valor:
                moeda(
                  calculo.totalPagoPassageiro /
                    rateio,
                ),
              validado: false,
            },
            { merge: true },
          );
        },
      );

      batch.set(
        vendaRef,
        {
          bilhetesEmitidos:
            passageiros.length,
        },
        { merge: true },
      );

      await batch.commit();

      res.status(200).json({
        vendaId,
        id_transacao: pagamentoId,
        qr_code_copia_cola: qrCode,
        qr_code_base64: qrCodeBase64,
        status:
          texto(pagamento.status) ||
          "pending",
        financeiro: {
          ...calculo,
          taxaProcessadorValor: taxaMp,
          receitaLiquidaPlataforma:
            receitaLiquida,
        },
      });
    } catch (error) {
      console.error(
        "Erro em gerarPixSeguro:",
        error,
      );

      if (
        error instanceof Error &&
        error.message === "UNAUTHENTICATED"
      ) {
        res.status(401).json({
          erro:
            "Faça login novamente antes de comprar.",
        });
        return;
      }

      res.status(500).json({
        erro:
          error instanceof Error
            ? error.message
            : "Falha interna ao gerar o Pix.",
      });
    }
  },
);

export const webhookMercadoPagoCmb = onRequest(
  {
    region: REGIAO,
    cors: false,
    secrets: [mercadoPagoAccessToken],
    timeoutSeconds: 60,
  },
  async (req, res) => {
    try {
      const pagamentoId = texto(
        (req.body as Record<string, any>)?.data
          ?.id ||
          req.query["data.id"] ||
          req.query.id,
      );

      if (!pagamentoId) {
        res.status(200).send("Ignorado");
        return;
      }

      const pagamento =
        await consultarPagamentoMercadoPago(
          pagamentoId,
          mercadoPagoAccessToken.value(),
        );
      const vendaId = texto(
        pagamento.external_reference,
      );

      if (!vendaId) {
        res.status(200).send("Sem referência");
        return;
      }

      const vendaRef = db
        .collection("vendas")
        .doc(vendaId);
      const vendaSnap = await vendaRef.get();

      if (!vendaSnap.exists) {
        res.status(200).send("Venda não localizada");
        return;
      }

      const venda = vendaSnap.data() || {};
      const valorEsperado = numero(
        venda.totalPagoPassageiro ||
          venda.valorTotalCobrado,
      );
      const valorRecebido = numero(
        pagamento.transaction_amount,
      );
      const valorConfere =
        Math.abs(valorEsperado - valorRecebido) <=
        0.01;
      const statusMp =
        texto(pagamento.status) || "pending";
      const taxaMp =
        taxaProcessador(pagamento);
      const receitaBruta = numero(
        venda.receitaBrutaPlataforma ||
          venda.taxaPlataformaValor,
      );

      const atualizacaoVenda: Record<
        string,
        unknown
      > = {
        pagamentoId,
        statusPagamento: valorConfere
          ? statusMp
          : "valor_inconsistente",
        statusVenda: valorConfere
          ? statusVenda(statusMp)
          : "auditoria_necessaria",
        taxaProcessadorValor: taxaMp,
        receitaLiquidaPlataforma: moeda(
          receitaBruta - taxaMp,
        ),
        valorRecebido,
        valorPagamentoConfere: valorConfere,
        atualizadoEm:
          admin.firestore.FieldValue.serverTimestamp(),
      };

      if (statusMp === "approved" && valorConfere) {
        atualizacaoVenda.pagoEm =
          admin.firestore.FieldValue.serverTimestamp();
      }

      const passagensSnap = await db
        .collection("passagens")
        .where("vendaId", "==", vendaId)
        .get();
      const batch = db.batch();

      batch.set(
        vendaRef,
        atualizacaoVenda,
        { merge: true },
      );

      passagensSnap.docs.forEach(
        (documento) => {
          batch.set(
            documento.ref,
            {
              status: valorConfere
                ? statusPassagem(statusMp)
                : "AUDITORIA",
              pagamentoStatus: statusMp,
              atualizadoEm:
                admin.firestore.FieldValue.serverTimestamp(),
            },
            { merge: true },
          );
        },
      );

      await batch.commit();

      res.status(200).send("OK");
    } catch (error) {
      console.error(
        "Erro no webhook Mercado Pago:",
        error,
      );
      res.status(500).send("Erro");
    }
  },
);

export const sincronizarVendaPorPassagem =
  onDocumentWritten(
    {
      region: REGIAO,
      document: "passagens/{ticketId}",
    },
    async (event) => {
      const depois = event.data?.after;

      if (!depois?.exists) {
        return;
      }

      const passagem = depois.data() || {};
      const vendaId = texto(
        passagem.vendaId,
      );

      if (!vendaId) {
        return;
      }

      const vendaRef = db
        .collection("vendas")
        .doc(vendaId);
      const vendaSnap = await vendaRef.get();

      if (!vendaSnap.exists) {
        return;
      }

      const venda = vendaSnap.data() || {};
      const statusAtualVenda = normalizar(
        venda.statusPagamento,
      );
      const statusAtualPassagem = texto(
        passagem.status,
      ).toUpperCase();

      if (
        statusAtualVenda === "approved" &&
        statusAtualPassagem !== "APROVADO"
      ) {
        await depois.ref.set(
          {
            status: "APROVADO",
            atualizadoEm:
              admin.firestore.FieldValue.serverTimestamp(),
          },
          { merge: true },
        );
        return;
      }

      const passagensSnap = await db
        .collection("passagens")
        .where("vendaId", "==", vendaId)
        .get();

      await vendaRef.set(
        {
          bilhetesEmitidos:
            passagensSnap.size,
          atualizadoEm:
            admin.firestore.FieldValue.serverTimestamp(),
        },
        { merge: true },
      );
    },
  );
